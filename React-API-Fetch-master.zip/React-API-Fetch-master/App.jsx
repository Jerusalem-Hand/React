import React, { useState, useEffect } from 'react';
import axios from 'axios';

class App extends React.Component {
	constructor(){
		super()
		this.state={
			res:{}
		}
  }
  
  componentDidMount(){
    this.fetchData()
  }

  fetchData(){
      const url = "https://hn.algolia.com/api/v1/search?query=redux"
      return fetch(url)
          .then(response => {
          	return response.json()
          })
          .then(parsedJSON => {
          	this.setState({res: parsedJSON})
          })
          .catch(error => console.log(error))
  }

  render() {
    return (
      <div>{this.state.res.query}</div>
    );
  }
}

export default App;
