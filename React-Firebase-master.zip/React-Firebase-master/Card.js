import React from 'react'
import firebase from './firebase.js'

class Card extends React.Component {
  constructor() {
    super();
    this.state = {
      currentItem: '',
      username: '',
      items: []
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.removeItem = this.removeItem.bind(this);
    this.updateItem = this.updateItem.bind(this);
  }

  handleChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  handleSubmit(e) {
    e.preventDefault();
    const itemsRef = firebase.database().ref('items');
    const item = {
      title: this.state.currentItem,
      user: this.state.username
    }
    itemsRef.push(item);
    this.setState({
      currentItem: '',
      username: ''
    });
  }

  componentDidMount() {
    const itemsRef = firebase.database().ref('items');
    itemsRef.on('value', (snapshot) => {
      let items = snapshot.val();
      let newState = [];
      for (let item in items) {
        newState.push({
          id: item,
          title: items[item].title,
          user: items[item].user
        });
      }
      this.setState({
        items: newState
      });
    });
  }

  removeItem(itemId) {
    const itemRef = firebase.database().ref(`/items/${itemId}`);
    itemRef.remove();
  }

  updateItem(itemId) {
    this.props.history.push({pathname: 'update', state: itemId});
  }

  render() {
    return (
      <div className='app'>
        <header>
            <div className="wrapper">
              <h1>Card</h1>
            </div>
        </header>
        <div className='container'>
          <section className='add-item'>
            <form className="was-validated" onSubmit={this.handleSubmit}>
              <div className="form-group">
                <label for="uname">Title:</label>
                <input type="text" className="form-control" name="username" onChange={this.handleChange} value={this.state.username} required/>
                <div className="valid-feedback">Valid.</div>
                <div className="invalid-feedback">Please fill out this field.</div>
              </div>
              <div className="form-group">
                <label for="pwd">User:</label>
                <input type="text" className="form-control" name="currentItem" onChange={this.handleChange} value={this.state.currentItem} required/>
                <div className="valid-feedback">Valid.</div>
                <div className="invalid-feedback">Please fill out this field.</div>
              </div>
              <button type="submit" className="btn btn-primary col">Add Item</button>
            </form>
          </section>
          <section className='display-item'>
              <div className="wrapper">
                <div className="row">
                  {this.state.items.map((item) => {
                    return (
                      <div key={item.id} className="col-lg-3">
                        <div className="item_box">
                          <h3>{item.title}</h3>
                          <p>Level : {item.user}</p>
                          <div className="row">
                            <button className="col btn btn-success" onClick={() => this.removeItem(item.id)}>Remove Item</button>
                            <button className="col btn btn-danger" onClick={() => this.updateItem(item.id)}>Update Item</button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
          </section>
        </div>
      </div>
    );
  }
}
export default Card