import React from 'react'
import firebase from './firebase.js'

class Update extends React.Component{
    constructor(){
        super()
        this.state = {
            update_id: '',
            title: '',
            user: ''
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount(){
        this.setState({
            update_id: this.props.history.location.state
        })
        const itemsRef = firebase.database().ref('items/'+ this.props.history.location.state)
        itemsRef.on('value', (snapshot) => {
            let items = snapshot.val()
            this.setState({
                title: items['title'],
                user: items['user']
            });
        })
    }

    handleChange(e) {
        this.setState({
          [e.target.name]: e.target.value
        });
    }

    handleSubmit(e) {
        e.preventDefault();
        const itemsRef = firebase.database().ref('items/'+ this.state.update_id);
        itemsRef.update({
            "title": this.state.title,
            "user": this.state.user
        })
        this.props.history.push({pathname: '/card'})
    }

    render() {
        return(
            <div className="app">
                <h1>Update</h1>
                <div className="container">
                    <form onSubmit={this.handleSubmit}>
                        <div className="form-group">
                            <label for="email">Title:</label>
                            <input type="text" className="form-control" id="user" value={this.state.user} placeholder="Enter user" onChange={this.handleChange} name="user"/>
                        </div>
                        <div className="form-group">
                            <label for="pwd">User:</label>
                            <input type="text" className="form-control" id="title" value={this.state.title} placeholder="Enter title" onChange={this.handleChange} name="title"/>
                        </div>
                        <button type="submit" className="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        )
    }
}

export default Update