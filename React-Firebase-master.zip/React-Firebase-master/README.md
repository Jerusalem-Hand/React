# react.js hello world
---
first, you should install node and npm.

1. init npm  
    `npm install`

2. start server  
    `npm start`

3. open browser: [http://localhost:7777](http://localhost:7777)

---
if you clone this repository to local, just `npm install` and `npm start`.

that is firebase integration react app.

  -firebase connect
  -routing, redirect with params
  -add, delete, update firebase realtime database