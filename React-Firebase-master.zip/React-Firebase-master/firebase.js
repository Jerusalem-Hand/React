import firebase from 'firebase'

const config = {
    apiKey: "AIzaSyAPxos6HZc2XoNxsJJppVbMSh3BriCWinY",
    databaseURL: "https://billa-2481f.firebaseio.com/",
    projectId: "billa-2481f"
};
firebase.initializeApp(config);

export default firebase;